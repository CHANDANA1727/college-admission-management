# College Admission Management — Mini Project

## Files
- `College_Admission_Management_SRS.pdf` — SRS document (exactly 2 pages)
- `index.html` — webpage structure
- `style.css` — separate stylesheet

## How to run
1. Keep `index.html` and `style.css` in the same folder.
2. Open `index.html` in a modern browser such as Google Chrome.
3. Use the navigation links to move between sections.
4. Resize the browser window to check the responsive layout.

## Note
This is a static front-end project made with HTML5 and CSS3. The enquiry form is for demonstration only and does not send or store data. Course names, contact details, and eligibility information are sample content.
